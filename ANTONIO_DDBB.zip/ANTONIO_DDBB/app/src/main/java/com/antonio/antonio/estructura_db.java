package com.antonio.antonio;

public class estructura_db {

    public static final int DB_VERSION = 1;
    public static final String TABLA = "hora";
    public static final String DBNAME = "antonio.db";

    //NOMBRE DE LAS COLUMNAS

    public static final String COLID = "";
    public static final String MES = "";

    //ARRAY DE COLUMNAS

    public static final String[] COLUMNAS = {COLID,MES};

    //CREAR BASE DATOS

    public static final String CREAR_TABLA = "CREATE TABLE "+TABLA+" ("
            +COLID+" INTEGER PRIMARY KEY, "+MES+" TEXT );";
}
