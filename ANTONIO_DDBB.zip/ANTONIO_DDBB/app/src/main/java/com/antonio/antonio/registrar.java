package com.antonio.antonio;

import android.app.Activity;
import android.os.Bundle;

public class registrar extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);




    }
}
